package com.railway.payment.repository;

import com.railway.payment.model.PaymentInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PaymentInfoRepository extends JpaRepository<PaymentInfo, Long> {

    // Optional: Add more queries if needed
    PaymentInfo findByStripePaymentIntentId(String paymentIntentId);
}
