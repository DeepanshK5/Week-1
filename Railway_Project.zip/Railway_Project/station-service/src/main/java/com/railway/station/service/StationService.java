package com.railway.station.service;

import com.railway.station.entity.Station;
import com.railway.station.exception.StationNotFoundException;
import com.railway.station.repository.StationRepository;
import org.apache.coyote.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StationService {

    @Autowired
    private StationRepository stationRepository;

    public ResponseEntity<Station> addStation(Station station){
        return new ResponseEntity<>(stationRepository.save(station), HttpStatus.OK);
    }

    public ResponseEntity<List<Station>>getAllStations(){
        List<Station> allStations = stationRepository.findAll();
        return new ResponseEntity<>(allStations,HttpStatus.OK);
    }

    public Optional<Station> getStationByCode(String stationCode){
        Optional<Station> byStationCode = stationRepository.findByStationCode(stationCode);
        if(!byStationCode.isPresent()){
            throw new StationNotFoundException("Not found station by station code");
        }
        return byStationCode;
    }

    public Optional<Station> getStationById(Long id){
        Optional<Station> station = stationRepository.findById(id);
        if (!station.isPresent()) {
            throw new StationNotFoundException("Station not found with id: " + id);
        }
        return station;
    }

    public ResponseEntity<String> deleteById(Long id){
        if (!stationRepository.existsById(id)) {
            throw new StationNotFoundException("Cannot delete. Station not found with id: " + id);
        }
        stationRepository.deleteById(id);
        return new ResponseEntity<>("Deleted Successfully", HttpStatus.OK);
    }

    public ResponseEntity<String> deleteByCode(String code) {
        Optional<Station> station = stationRepository.findByStationCode(code);
        if (!station.isPresent()) {
            throw new StationNotFoundException("Cannot delete. Station not found with code: " + code);
        }
        stationRepository.deleteByStationCode(code);
        return new ResponseEntity<>("Deleted Successfully", HttpStatus.OK);
    }
}
