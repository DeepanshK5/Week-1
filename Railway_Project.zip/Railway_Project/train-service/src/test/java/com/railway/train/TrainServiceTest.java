package com.railway.train;

import com.railway.train.entity.Train;
import com.railway.train.external.StationServiceClient;
import com.railway.train.model.Station;
import com.railway.train.repository.TrainRepository;
import com.railway.train.service.TrainService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class TrainServiceTest {

    @Mock
    private StationServiceClient stationServiceClient;

    @Mock
    private TrainRepository trainRepository;

    @InjectMocks
    private TrainService trainService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testSaveTrain_Success() {
        // Prepare train and stations
        Station stationInput = Station.builder()
                .id(1L)
                .arrivalTime(LocalTime.of(10, 0))
                .departureTime(LocalTime.of(10, 15))
                .fareTillThis(100)
                .build();

        Train train = Train.builder()
                .id(1L)
                .trainName("Express")
                .trainNumber("EXP123")
                .travelDate(LocalDate.now().plusDays(1))
                .availableSeats(50)
                .stationList(List.of(stationInput))
                .build();

        // Mock stationServiceClient to return full station info
        Station fullStation = Station.builder()
                .id(1L)
                .stationCode("STN1")
                .stationName("Station 1")
                .build();

        when(stationServiceClient.getStationById(1L)).thenReturn(Optional.of(fullStation));
        when(trainRepository.save(any(Train.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Train savedTrain = trainService.saveTrain(train);

        assertNotNull(savedTrain);
        assertEquals(1, savedTrain.getStationList().size());
        assertEquals("STN1", savedTrain.getStationList().get(0).getStationCode());
        assertEquals("Station 1", savedTrain.getStationList().get(0).getStationName());
        assertEquals(train.getAvailableSeats(), savedTrain.getStationList().get(0).getLeftSeat());

        verify(stationServiceClient, times(2)).getStationById(1L);
        verify(trainRepository).save(any(Train.class));
    }


    @Test
    void testGetAllTrains_ReturnsList() {
        Train train1 = new Train();
        Train train2 = new Train();

        when(trainRepository.findAll()).thenReturn(List.of(train1, train2));

        List<Train> trains = trainService.getAllTrains();

        assertEquals(2, trains.size());
        verify(trainRepository).findAll();
    }

    @Test
    void testSearchTrain_FindsMatchingTrains() {
        Station s1 = Station.builder().stationCode("SRC").build();
        Station s2 = Station.builder().stationCode("DST").build();

        Train train = Train.builder()
                .travelDate(LocalDate.of(2025, 6, 27))
                .stationList(List.of(s1, s2))
                .build();

        when(trainRepository.findAll()).thenReturn(List.of(train));

        List<Train> result = trainService.searchTrain("SRC", "DST", LocalDate.of(2025, 6, 27));

        assertEquals(1, result.size());
        assertEquals(train, result.get(0));
    }

    @Test
    void testSearchTrain_NoMatchingTrains_Throws() {
        when(trainRepository.findAll()).thenReturn(Collections.emptyList());

        RuntimeException ex = assertThrows(RuntimeException.class,
                () -> trainService.searchTrain("SRC", "DST", LocalDate.of(2025, 6, 27)));

        assertTrue(ex.getMessage().contains("No trains found for this route"));
    }

    @Test
    void testGetTrainById_Found() {
        Train train = new Train();
        when(trainRepository.findById(1L)).thenReturn(Optional.of(train));

        Train result = trainService.getTrainById(1L);

        assertEquals(train, result);
    }


    @Test
    void testDeleteTrain_VerifyDeleteCalled() {
        doNothing().when(trainRepository).deleteById(1L);

        trainService.deleteTrain(1L);

        verify(trainRepository).deleteById(1L);
    }

    @Test
    void testUpdateAvailableSeats_Success() {
        Train train = Train.builder()
                .availableSeats(10)
                .build();

        when(trainRepository.findById(1L)).thenReturn(Optional.of(train));
        when(trainRepository.save(any(Train.class))).thenAnswer(i -> i.getArgument(0));

        Train updatedTrain = trainService.updateAvailableSeats(1L, 5);

        assertEquals(15, updatedTrain.getAvailableSeats());
        verify(trainRepository).save(updatedTrain);
    }

    @Test
    void testUpdateAvailableSeats_ThrowsIfSeatsNegative() {
        Train train = Train.builder()
                .availableSeats(3)
                .build();

        when(trainRepository.findById(1L)).thenReturn(Optional.of(train));

        RuntimeException ex = assertThrows(RuntimeException.class,
                () -> trainService.updateAvailableSeats(1L, -5));

        assertEquals("Not enough seats are available", ex.getMessage());
    }
}
