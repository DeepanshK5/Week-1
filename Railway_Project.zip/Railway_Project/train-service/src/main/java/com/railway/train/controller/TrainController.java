package com.railway.train.controller;

import com.railway.train.entity.Train;
import com.railway.train.exception.TrainNotFoundException;
import com.railway.train.service.TrainService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.ws.rs.Path;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/trains")
@Tag(name = "Train Controller",description = "CRUD Operations Related To Train")
public class TrainController {

    @Autowired
    private TrainService trainService;

    @PostMapping
    @Operation(summary = "Add Train {Admin Only}")
    public ResponseEntity<Train> addTrain(@Valid @RequestBody Train train) {
        return ResponseEntity.ok(trainService.saveTrain(train));
    }

    @GetMapping("/all")
    @Operation(summary = "Get All Trains {User}")
    public ResponseEntity<List<Train>> getAll() {
        return ResponseEntity.ok(trainService.getAllTrains());
    }

    @GetMapping("/search")
    @Operation(summary = "Search Train By Source, Destination And Date(yyyy-MM-DD) {User}")
    public ResponseEntity<List<Train>> searchTrains(
            @RequestParam String source,
            @RequestParam String destination,
            @RequestParam String date
    ) {
        LocalDate travelDate = LocalDate.parse(date); // format must be yyyy-MM-dd
        List<Train> trains = trainService.searchTrain(source, destination, travelDate);
        return ResponseEntity.ok(trains);
    }

    @GetMapping("/id/{id}")
    @Operation(summary = "Get Train By Id {User}")
    public ResponseEntity<Train> getTrainById(@PathVariable Long id){
        Train trainById = trainService.getTrainById(id);
        return new ResponseEntity<>(trainById, HttpStatus.OK);
    }

    @PutMapping("/update-seats/{id}")
    @Operation(summary = "Update Seats Only For Feign Client {Feign Client Only}")
    public ResponseEntity<Train> updateSeats(@PathVariable Long id, @RequestParam int count) {
        Train updatedTrain = trainService.updateAvailableSeats(id, count);
        return ResponseEntity.ok(updatedTrain);
    }


    @DeleteMapping("/{id}")
    @Operation(summary = "Delete Train By Id {Admin Only}")
    public ResponseEntity<String> deleteTrainById(@PathVariable Long id){
        Train trainById = trainService.getTrainById(id);
        trainService.deleteTrain(id);
        return ResponseEntity.ok("Train Deleted Successfully");
    }
}
