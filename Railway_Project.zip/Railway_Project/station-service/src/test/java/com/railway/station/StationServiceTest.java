package com.railway.station;

import com.railway.station.entity.Station;
import com.railway.station.repository.StationRepository;
import com.railway.station.service.StationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class StationServiceTest {

    @Mock
    private StationRepository stationRepository;

    @InjectMocks
    private StationService stationService;

    private Station sampleStation;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        sampleStation = Station.builder()
                .id(1L)
                .stationCode("BPL")
                .stationName("Bhopal")
                .availableSeats(50)
                .totalSeats(100)
                .build();
    }

    @Test
    void testAddStation_ShouldReturnSavedStation() {
        when(stationRepository.save(any(Station.class))).thenReturn(sampleStation);

        ResponseEntity<Station> response = stationService.addStation(sampleStation);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(sampleStation, response.getBody());
        verify(stationRepository).save(sampleStation);
    }

    @Test
    void testGetAllStations_ShouldReturnList() {
        List<Station> stationList = List.of(sampleStation);
        when(stationRepository.findAll()).thenReturn(stationList);

        ResponseEntity<List<Station>> response = stationService.getAllStations();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(1, response.getBody().size());
        assertEquals(sampleStation, response.getBody().get(0));
    }

    @Test
    void testGetStationByCode_Exists_ShouldReturnStation() {
        when(stationRepository.findByStationCode("BPL")).thenReturn(Optional.of(sampleStation));

        Optional<Station> result = stationService.getStationByCode("BPL");

        assertTrue(result.isPresent());
        assertEquals("BPL", result.get().getStationCode());
    }

    @Test
    void testGetStationByCode_NotFound_ShouldThrow() {
        when(stationRepository.findByStationCode("XYZ")).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class,
                () -> stationService.getStationByCode("XYZ"));

        assertEquals("Not found station by station code", exception.getMessage());
    }

    @Test
    void testGetStationById_Found_ShouldReturnStation() {
        when(stationRepository.findById(1L)).thenReturn(Optional.of(sampleStation));

        Optional<Station> result = stationService.getStationById(1L);

        assertTrue(result.isPresent());
        assertEquals(1L, result.get().getId());
    }

    @Test
    void testGetStationById_NotFound_ShouldReturnEmpty() {
        when(stationRepository.findById(99L)).thenReturn(Optional.empty());

        Optional<Station> result = stationService.getStationById(99L);

        assertFalse(result.isPresent());
    }

    @Test
    void testDeleteById_ShouldReturnSuccessMessage() {
        doNothing().when(stationRepository).deleteById(1L);

        ResponseEntity<String> response = stationService.deleteById(1L);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Deleted Successfully", response.getBody());
        verify(stationRepository).deleteById(1L);
    }
}
