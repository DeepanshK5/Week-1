package com.railway.user_service;

import com.railway.user_service.entity.User;
import com.railway.user_service.repository.UserRepository;
import com.railway.user_service.service.JwtService;
import com.railway.user_service.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class UserServiceTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private BCryptPasswordEncoder passwordEncoder;

    @Mock
    private AuthenticationManager authenticationManager;

    @Mock
    private JwtService jwtService;

    @InjectMocks
    private UserService userService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testRegister_ShouldEncodePasswordAndSaveUser() {
        // Arrange
        User user = new User();
        user.setPassword("plainPassword");

        when(passwordEncoder.encode("plainPassword")).thenReturn("encodedPassword");
        when(userRepository.save(user)).thenReturn(user);

        // Act
        User registeredUser = userService.register(user);

        // Assert
        assertEquals("encodedPassword", registeredUser.getPassword());
        verify(userRepository, times(1)).save(user);
    }

    @Test
    void testVerify_ShouldReturnTokenIfAuthenticated() {
        User inputUser = new User();
        inputUser.setUsername("testuser");
        inputUser.setPassword("plain");

        User dbUser = new User();
        dbUser.setUsername("testuser");

//         Hardcode repository to return user
        when(userRepository.findByUsername(anyString())).thenReturn(Optional.of(dbUser));


        // Hardcode JWT token
        when(jwtService.generateToken(any())).thenReturn("token");

        // Hardcode Authentication to always be authenticated
        Authentication auth = mock(Authentication.class);
        when(authenticationManager.authenticate(any())).thenReturn(auth);
        when(auth.isAuthenticated()).thenReturn(true);


        assertEquals("token", jwtService.generateToken(inputUser));
    }


    @Test
    void testVerify_ShouldReturnFailureIfNotAuthenticated() {
        User inputUser = new User();
        inputUser.setUsername("testuser");
        inputUser.setPassword("plain");

        when(userRepository.findByUsername("testuser")).thenReturn(Optional.of(new User()));

        Authentication auth = mock(Authentication.class);
        when(authenticationManager.authenticate(any())).thenReturn(auth);
        when(auth.isAuthenticated()).thenReturn(false);

        // Act
        String result = userService.verify(inputUser);

        // Assert
        assertEquals("Failure", result);
    }
}
