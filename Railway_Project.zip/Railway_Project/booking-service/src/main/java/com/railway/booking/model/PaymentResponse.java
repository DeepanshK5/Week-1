package com.railway.booking.model;

public class PaymentResponse {
    private String clientSecret;
    private String status;
    private String paymentIntentId;   // add this

    public PaymentResponse(String clientSecret, String status, String paymentIntentId) {
        this.clientSecret = clientSecret;
        this.status = status;
        this.paymentIntentId = paymentIntentId;
    }

    // getters and setters
    public String getClientSecret() { return clientSecret; }
    public void setClientSecret(String clientSecret) { this.clientSecret = clientSecret; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getPaymentIntentId() { return paymentIntentId; }
    public void setPaymentIntentId(String paymentIntentId) { this.paymentIntentId = paymentIntentId; }
}
