package com.railway.station.controller;

import com.netflix.discovery.converters.Auto;
import com.railway.station.entity.Station;
import com.railway.station.service.StationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.ws.rs.Path;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/station")
@Tag(name = "Station Controller",description = "CRUD Operations Related To Station")
public class StationController {

    @Autowired
    private StationService stationService;

    @PostMapping("/add")
    @Operation(summary = "Add Station {Admin Only}")
    public ResponseEntity<Station> addStation(@RequestBody Station station){
        return stationService.addStation(station);
    }

    @GetMapping("/all")
    @Operation(summary = "Get All Stations {User}")
    public ResponseEntity<List<Station>> getAllStations(){
        return stationService.getAllStations();
    }

    @GetMapping("/code/{code}")
    @Operation(summary = "Get Stations By Code {User}")
    public Optional<Station> getStationByCode(@PathVariable String code){
        return stationService.getStationByCode(code);
    }

    @GetMapping("/id/{id}")
    @Operation(summary = "Get Stations By Id {User}")
    public Optional<Station> getStationById(@PathVariable Long id){
        return stationService.getStationById(id);
    }

    @DeleteMapping("delete/id/{id}")
    @Operation(summary = "Delete Station By Id {Admin Only}")
    public ResponseEntity<?> deleteStationById(@PathVariable Long id){
        return stationService.deleteById(id);
    }

    @DeleteMapping("delete/code/{code}")
    @Operation(summary = "Delete Station By Code {Admin Only}")
    public ResponseEntity<?> deleteStationByCode(@PathVariable String code){
        return stationService.deleteByCode(code);
    }

}
